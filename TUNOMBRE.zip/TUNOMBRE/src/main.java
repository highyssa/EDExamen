import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		Scanner scanner = new Scanner (System.in);
		
		System.out.println("¿Cual es tu edad?");
		int edad = scanner.nextInt();
		
		System.out.println("Hola, tu edad es: " + edad);
		scanner.close();

	}

}
